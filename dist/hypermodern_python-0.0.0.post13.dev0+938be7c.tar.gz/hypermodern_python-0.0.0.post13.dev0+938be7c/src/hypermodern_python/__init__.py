"""The hypermodern Python project."""

import argparse

__version__ = "0.0.0.post13.dev0+938be7c"


def main():
    parser = argparse.ArgumentParser(prog="random-wikipedia-article")
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )
    parser.parse_args()
